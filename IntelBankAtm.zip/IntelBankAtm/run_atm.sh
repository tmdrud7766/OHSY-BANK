#!/bin/bash

# 작업 디렉토리로 이동
cd /home/willtek/work/practice_device_bd/IntelBankAtm

# 로그 디렉토리와 파일 경로 설정
LOG_DIR="logs"
LOG_FILE="$LOG_DIR/client_log.txt"
CCTV_DIR="./cctv"

# 로그 디렉토리가 없으면 생성
if [ ! -d "$LOG_DIR" ]; then
    mkdir -p "$LOG_DIR"
    echo "Created log directory: $LOG_DIR"
fi

# 로그 파일이 없으면 생성
if [ ! -f "$LOG_FILE" ]; then
    touch "$LOG_FILE"
    echo "Created log file: $LOG_FILE"
fi

# CCTV 디렉토리가 없으면 생성
if [ ! -d "$CCTV_DIR" ]; then
    mkdir -p "$CCTV_DIR"
    echo "Created CCTV directory: $CCTV_DIR"
fi

# 날짜와 시작 시간을 로그에 기록
echo "=== Script started at $(date) ===" >> "$LOG_FILE"

./intel_bank_atm_client ./cctv &

# ATM 로그인 프로그램 실행 (로그 추가)
./intel*bank*atm_login

echo "Programs started - check $LOG_FILE for logs"